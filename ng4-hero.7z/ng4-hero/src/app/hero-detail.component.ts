import { Component, Input } from '@angular/core';

import { Hero } from './hero';
@Component({
  selector: 'hero-detail',
  template: `
    <div *ngIf="hero">

      <div>id: {{hero.id}}</div>

      <div>
        name: <input [(ngModel)]="hero.name"/>
      </div>

    </div>
  `
})
export class HeroDetailComponent {
  @Input() hero: Hero;
}

