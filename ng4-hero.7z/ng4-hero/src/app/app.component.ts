import { Component, HostListener, Input, ElementRef, AfterViewInit, ViewChild, OnInit, Output, EventEmitter } from '@angular/core';

import { Hero } from './hero';

@Component({
  selector: 'my-app',
  template: `
    
    <hero-detail [hero]="selectedHero"></hero-detail>

    <ul class="heroes">
      <li *ngFor="let hero of heroes" [class.selected]="hero === selectedHero" 
      (click)="onSelect(hero)">

        <span class="badge">{{hero.id}}</span> {{hero.name}}

      </li>
    </ul>

    <div id="div1" #div1 (myClick)="showEventObject($event)">D1</div>
    <div id="div2" #div2>D2</div>
  `,
  styles: [`
    .selected {
      background-color: #CFD8DC !important;
      color: white;
    }
    .heroes {
      margin: 0 0 2em 0;
      list-style-type: none;
      padding: 0;
      width: 15em;
    }
    .heroes li {
      cursor: pointer;
      position: relative;
      left: 0;
      background-color: #EEE;
      margin: .5em;
      padding: .3em 0;
      height: 1.6em;
      border-radius: 4px;
    }
    .heroes li.selected:hover {
      background-color: #BBD8DC !important;
      color: white;
    }
    .heroes li:hover {
      color: #607D8B;
      background-color: #DDD;
      left: .1em;
    }
    .heroes .text {
      position: relative;
      top: -3px;
    }
    .heroes .badge {
      display: inline-block;
      font-size: small;
      color: white;
      padding: 0.8em 0.7em 0 0.7em;
      background-color: #607D8B;
      line-height: 1em;
      position: relative;
      left: -1px;
      top: -4px;
      height: 1.8em;
      margin-right: .8em;
      border-radius: 4px 0 0 4px;
    }
  `]
})
export class AppComponent implements OnInit, AfterViewInit {

  @ViewChild('div1') private div1: ElementRef;
  @ViewChild('div2') private div2: ElementRef;
  @Output() onAdd = new EventEmitter<Object>();

  @Output("div1") emDiv1Click = new EventEmitter<void>();

  clickMessage: string;
  _object: {};
  showEventObject(event: any) {
    console.log(event);
    this.clickMessage = event;
  }
  test1() {
    return { id: "555", name: "Pob" };
  }
  test2() {
    return { id: "444", name: "Saeng" };
  }
  print(_object: {}) {
     console.log(_object); 
  }
  ngAfterViewInit(): void {
    this.div1.nativeElement.addEventListener('click', (event: Event) => {
      this.emDiv1Click.emit( this.print(this.test1()) );
    });
    
    this.div2.nativeElement.addEventListener('click', (event: Event) => {
      this.emDiv1Click.emit( this.print(this.test2()) );
    })

    // this.onAdd.emit(this._object = this.test());
    // console.log(this._object);

  }
  ngOnInit(): void { }

  heroes: Hero[];
  selectedHero: Hero;

  constructor() {
    this.heroes = [
      { id: 1, name: 'Mr. Nice' },
      { id: 2, name: 'Narco' },
      { id: 3, name: 'Bombasto' },
      { id: 4, name: 'Celeritas' },
      { id: 5, name: 'Magneta' }
    ];
  }

  onSelect(hero: Hero): void {
    this.selectedHero = hero;
    console.dir(this.selectedHero);
  }
}
